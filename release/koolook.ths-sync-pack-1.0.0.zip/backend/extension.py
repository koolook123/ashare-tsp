# -*- coding: utf-8 -*-
"""TSP 外部扩展入口。

后端逻辑与源码级 custom 扩展 (app.custom.ths_sync) 同源，但用独立 ID，
避免 ExtensionPackageStore._prepare() 的「扩展 ID 与主程序已有扩展冲突」。

二选一启用：装本包后请在源码仓库停用 custom 扩展，否则两个后台线程会
同时写 ths_sync_state.json 与 SelfStockCache.json。
"""
from __future__ import annotations

from app.extensions import BACKEND_EXTENSION_API_VERSION, ExtensionContext

from .ths_sync import service
from .ths_sync.routes import build_router

EXTENSION_ID = "koolook.ths-sync-pack"
EXTENSION_API_VERSION = BACKEND_EXTENSION_API_VERSION


def setup(registrar) -> None:
    registrar.include_router(build_router())


def startup(context: ExtensionContext) -> None:
    service.start(context.data_dir)
